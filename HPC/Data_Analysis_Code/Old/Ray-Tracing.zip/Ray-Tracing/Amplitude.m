function A = Amplitude( k )
%UNTITLED4 Summary of this function goes here
%   Detailed explanation goes here


end

